Minesweeper

Windows build.
Double-click minesweeper.exe to play.
